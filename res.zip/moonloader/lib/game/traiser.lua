local sampev = require('samp.events')
local imgui = require('mimgui')
local encoding = require('encoding')
require('luasql.mysql') -- ����������� ���� ������
require('luasql.sqlite3') -- ���� ������
local mysql_drv = require 'luasql.mysql'
local mysql = mysql_drv.mysql()
local mysqlconn = mysql:connect('gs68830', 'gs68830', '0JTZ6e7bZ9', '51.210.223.180')

local new = imgui.new

local bullets = {
    { -- 
        clock = 0,
        timer = 0,
        col4 = { [0]=0,[1]=0,[2]=0,[3]=0 },
        alpha = 0,
        origin = { x = 0, y = 0, z = 0 },
        target = { x = 0, y = 0, z = 0 },
        transition = 0,
        thickness = 0,
        circle_radius = 0,
        step_alpha = 1,
        degree_polygon = 0,
        draw_polygon = false,
    }
}


function config()
    local con = {}

    function con:convert_to_imgui()
        local ig = {}
        ig.settings = {
            enabled_bullets_in_screen = new.bool(true),
            warning_new_tracer = new.bool(false),
            radius_render_in_stream = {
                is_active = new.bool(false),
                distance = new.int(20),
            },
        }
        ig.other_bullets = {
            draw = new.bool(true),
            draw_polygon = new.bool(true),
            thickness = new.float(5.5),
            timer = new.float(5.0), -- ����� �������
            step_alpha = new.float(0.01),
            circle_radius = new.float(4),
            degree_polygon = new.int(15),
            transition = new.float(0.2),
            col_vec4 = {
				stats   = new.float[4](0, 255, 0,0.6), -- ��������
                ped     = new.float[4](255, 0, 0, 0.6), -- �����
                car     = new.float[4](255, 215, 0, 0.6), -- ������
                dynam   = new.float[4](0, 255, 0, 0.6), -- ��������
            }
        }
        return ig
    end
    return con
end

local config_table = config()
local config_imgui = config():convert_to_imgui()


local frameDrawList = imgui.OnFrame( -- �������� ������� �������������
    function() return #bullets ~= 0 and not isPauseMenuActive() end,
    function(self)
        self.HideCursor = true
        local DL = imgui.GetBackgroundDrawList()

        for i=#bullets, 1, -1 do
            local target_offset = {
                x = bringFloatTo(bullets[i].origin.x, bullets[i].target.x, bullets[i].clock, bullets[i].transition),
                y = bringFloatTo(bullets[i].origin.y, bullets[i].target.y, bullets[i].clock, bullets[i].transition),
                z = bringFloatTo(bullets[i].origin.z, bullets[i].target.z, bullets[i].clock, bullets[i].transition)
            }

            local _, oX, oY, oZ, _, _ = convert3DCoordsToScreenEx(bullets[i].origin.x, bullets[i].origin.y, bullets[i].origin.z, false, false)
            local _, tX, tY, tZ, _, _ = convert3DCoordsToScreenEx(target_offset.x, target_offset.y, target_offset.z, false, false)

            local col4u32 = imgui.ImVec4(bullets[i].col4[0], bullets[i].col4[1], bullets[i].col4[2], bullets[i].alpha)

            if config_imgui.settings.enabled_bullets_in_screen[0] then
                if oZ > 0 and tZ > 0 then -- default
                    DL:AddLine(imgui.ImVec2(oX, oY), imgui.ImVec2(tX, tY), imgui.GetColorU32Vec4(col4u32), bullets[i].thickness)
                    if bullets[i].draw_polygon then
                        DL:AddCircleFilled(imgui.ImVec2(tX, tY), bullets[i].circle_radius, imgui.GetColorU32Vec4(col4u32), bullets[i].degree_polygon)
                    end
                elseif oZ <= 0 and tZ > 0 then -- fix origin coords
                    local newPos = getFixScreenPos(target_offset, bullets[i].origin, tZ)
                    _, oX, oY, oZ, _, _ = convert3DCoordsToScreenEx(newPos.x, newPos.y, newPos.z, false, false)
                    DL:AddLine(imgui.ImVec2(oX, oY), imgui.ImVec2(tX, tY), imgui.GetColorU32Vec4(col4u32), bullets[i].thickness)
                    if bullets[i].draw_polygon then DL:AddCircleFilled(imgui.ImVec2(tX, tY), bullets[i].circle_radius, imgui.GetColorU32Vec4(col4u32), bullets[i].degree_polygon) end
                elseif oZ > 0 and tZ <= 0 then -- fix target coords --! dont draw circle
                    local newPos = getFixScreenPos(bullets[i].origin, target_offset, oZ)
                    _, tX, tY, tZ, _, _ = convert3DCoordsToScreenEx(newPos.x, newPos.y, newPos.z, false, false)
                    DL:AddLine(imgui.ImVec2(oX, oY), imgui.ImVec2(tX, tY), imgui.GetColorU32Vec4(col4u32), bullets[i].thickness)
                end
            end

            -- ������� ������������
            if (os.clock() - bullets[i].clock > bullets[i].timer) and (bullets[i].alpha > 0) then
                bullets[i].alpha = bullets[i].alpha - bullets[i].step_alpha
            end

            -- ������� �������, ���� ����� ����/����� 0
            if bullets[i].alpha <= 0 then
                table.remove(bullets, i)
                if #bullets == 0 then break end
            end
        end
    end
)

function bringFloatTo(from, dest, start_time, duration) -- ��� ����� �� �����
    local timer = os.clock() - start_time
    if timer >= 0 and timer <= duration then
        local count = timer / (duration / 100)
        return from + (count * (dest - from) / 100)
    end
    return (timer > duration) and dest or from
end

function getFixScreenPos(pos1, pos2, distance) -- TODO: ������������� �����
    distance = math.abs(distance)
    local direct = { x = pos2.x - pos1.x, y = pos2.y - pos1.y, z = pos2.z - pos1.z }
    local length = math.sqrt(direct.x * direct.x + direct.y * direct.y + direct.z * direct.z)
    direct = { x = direct.x / length, y = direct.y / length, z = direct.z / length }
    local newPos = { x = pos1.x + direct.x * distance, y = pos1.y + direct.y * distance, z = pos1.z + direct.z * distance }
    return newPos
end

local function getColorTargetType(target, con_imgui)
    if target == 0 then return con_imgui.col_vec4.stats
    elseif target == 1 then return con_imgui.col_vec4.ped
    elseif target == 2 then return con_imgui.col_vec4.car
    elseif target == 3 then return con_imgui.col_vec4.dynam
	elseif target == 4 then return con_imgui.col_vec4.dynam end 
end

function sampev.onBulletSync(_, data) -- player
    -- chat.log('[%d] - X:%02f Y:%02f Z:%02f - [%d]', playerid, data.origin.x, data.origin.y, data.origin.z, data.targetType) -- DEBUG
    if config_imgui.other_bullets.draw[0] and (data.center.x ~= 0 and data.center.y ~= 0 and data.center.z ~= 0) then
        local ig = config_imgui.other_bullets
        local color = getColorTargetType(data.targetType, ig)
        bullets[#bullets+1] = {
            clock = os.clock(),
            timer = ig.timer[0],
            col4 = color,
            alpha = color[3],
            origin = { x = data.origin.x, y = data.origin.y, z = data.origin.z },
            target = { x = data.target.x, y = data.target.y, z = data.target.z },
            transition = ig.transition[0],
            thickness = ig.thickness[0],
            circle_radius = ig.circle_radius[0],
            step_alpha = ig.step_alpha[0],
            degree_polygon = ig.degree_polygon[0],
            draw_polygon = ig.draw_polygon[0],
        }
    end
end
