local ffi = require "ffi"
local imgui = require('mimgui')

--// �������� �������� //--
local Warning = renderLoadTextureFromFile('moonloader/Admin Tools/notifications/Warning.png') -- cmd_info
local main_recon = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/main_recon.png') -- ����������� � �����
local slap = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/slap.png') -- CMD:slap
local flip = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/flip.png') -- CMD:flip
local getcar = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/getcar.png') -- CMD:getcar
local gethere = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/gethere.png') -- CMD:gethere
local stats = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/info.png') -- CMD:stats
local next = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/next.png') -- CMD:next
local reset = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/reset.png') -- CMD:reset
local back = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/back.png') -- CMD:back
local auncuff = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/auncuff.png') -- CMD:auncuff
local unfreeze = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/aunfreezel.png') -- CMD:unfreeze
local cmd_info = renderLoadTextureFromFile('moonloader/Admin Tools/recon_panel/cmd_info.png') -- cmd_info
local house = renderLoadTextureFromFile('moonloader/Admin Tools/main/house.png') -- ������ �������
local account = renderLoadTextureFromFile('moonloader/Admin Tools/main/account.png') -- ������ �������
local settings = renderLoadTextureFromFile('moonloader/Admin Tools/main/settings.png') -- ������ �������� 
local reload = renderLoadTextureFromFile('moonloader/Admin Tools/main/reload.png') -- ������ ����������

--// �������� ������� //--
local font_notificatios = renderCreateFont("Aria",8, 1) -- ����� ��������� ������
local font_notificatios_title = renderCreateFont("Aria",11, 0) -- ����� �������� ������
local font_button3_title = renderCreateFont("Aria", 9, 3) -- ����� ���������� ������ (Button_3)
local font_button3_text = renderCreateFont("Aria", 9, 2) -- ����� ������ (Button_3)
local text_rinfo = renderCreateFont("Aria", 9, 1)
local button_texts = renderCreateFont("Aria", 11, 0)

--// �������������� // --
notifications_ADD = function(title, text)
	local resX, resY = getScreenResolution()
	renderDrawTexture(Warning, resX  - 270, resY - 280, 260, 70, 0, 0xFFFFFFFF)
	renderFontDrawText(font_notificatios_title, title, resX  - 181, resY - 272, 0xFFFFFFFF)
	renderFontDrawText(font_notificatios, text, resX  - 183, resY - 248, 0xFFFFFFFF)
end



button_text3 = function(text,text2,text3, posX, posY, sizeX, sizeY, color, colorA)
	renderDrawBox(posX, posY, sizeX, sizeY, color)
	renderFontDrawText(font_button3_title, text, posX + sizeX/3 - 120 , posY + sizeY/3-20, 0xFFFFFFFF)
	renderFontDrawText(font_button3_text, text2, posX + sizeX/3 - 120 , posY + sizeY/3- 0, 0xFFFFFFFF)
	renderFontDrawText(font_button3_text, text3, posX + sizeX/3 - 120 , posY + sizeY/3- -20, 0xFFFFFFFF)
	local curX, curY = getCursorPos()
	if curX >= posX and curX <= posX + sizeX and curY >= posY and curY <= posY + sizeY then
		renderDrawBox(posX, posY, sizeX, sizeY, colorA)
		renderFontDrawText(font_button3_text, text2, posX + sizeX/3 - 120 , posY + sizeY/3- 0, 0xFFFFFFFF)
		renderFontDrawText(font_button3_text, text3, posX + sizeX/3 - 120 , posY + sizeY/3- -20, 0xFFFFFFFF)
		if isKeyJustPressed(0x01) then
			return true
		end
   end
end

reconplanels = function(x, y, xpos, ypos, id)
	if id == 1 then renderDrawTexture(slap, x, y, xpos, ypos, 0, 0xFFFFFFFF)
	elseif id == 2 then renderDrawTexture(flip, x, y, xpos, ypos, 0, 0xFFFFFFFF)
	elseif id == 3 then renderDrawTexture(getcar, x, y, xpos, ypos, 0, 0xFFFFFFFF)
	elseif id == 4 then renderDrawTexture(gethere, x, y, xpos, ypos, 0, 0xFFFFFFFF)
	elseif id == 5 then renderDrawTexture(stats, x, y, xpos, ypos, 0, 0xFFFFFFFF)
	elseif id == 7 then renderDrawTexture(next, x, y, xpos, ypos, 0, 0xFFFFFFFF)
	elseif id == 6 then renderDrawTexture(reset, x, y, xpos, ypos, 0, 0xFFFFFFFF)
	elseif id == 8 then renderDrawTexture(back, x, y, xpos, ypos, 0, 0xFFFFFFFF)
	elseif id == 9 then renderDrawTexture(auncuff, x, y, xpos, ypos, 0, 0xFFFFFFFF)
	elseif id == 10 then renderDrawTexture(unfreeze, x, y, xpos, ypos, 0, 0xFFFFFFFF)end 
    local cx, cy = getCursorPos() -- �������� ������ �����
    local res = false -- ������ ������� ������
	if cx > x and cx < x+45 and cy > y and cy < y+44 then -- ��������� ��������� ������ ����� � ������������� ������� 150 �� 30 ������
		if id == 1 then 
			renderDrawTexture(slap, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)
			renderDrawTexture(cmd_info, x+23, y-1, 137, 44, 0, 0xFFFFFFFF)-- �������
			renderFontDrawText(text_rinfo, "����������", x+65, y+12, 0xebedf1FF)
		elseif id == 2 then 
			renderDrawTexture(flip, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)
			renderDrawTexture(cmd_info, x+23, y-1, 137, 44, 0, 0xFFFFFFFF)-- �������
			renderFontDrawText(text_rinfo, "��������", x+70, y+12, 0xebedf1FF)
		elseif id == 3 then 
			renderDrawTexture(getcar, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)
			renderDrawTexture(cmd_info, x+6,  y-1, 250, 44, 0, 0xFFFFFFFF)-- �������
			renderFontDrawText(text_rinfo, "��������������� � ���� ����", x+60, y+12, 0xebedf1FF)
		elseif id == 4 then 
			renderDrawTexture(gethere, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)
			renderDrawTexture(cmd_info, x+13,  y-1, 210, 44, 0, 0xFFFFFFFF)-- �������
			renderFontDrawText(text_rinfo, "��������������� � ����", x+60, y+12, 0xebedf1FF)
		elseif id == 5 then 
			renderDrawTexture(stats, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)
			renderDrawTexture(cmd_info, x+23,  y-1, 137, 44, 0, 0xFFFFFFFF)-- �������
			renderFontDrawText(text_rinfo, "����������", x+65, y+12, 0xebedf1FF)
		elseif id == 7 then 
			renderDrawTexture(next, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)
			renderDrawTexture(cmd_info, x+23,  y-1, 137, 44, 0, 0xFFFFFFFF)-- �������
			renderFontDrawText(text_rinfo, "����. ID", x+65, y+12, 0xebedf1FF)
		elseif id == 6 then 
			renderDrawTexture(reset, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)
			renderDrawTexture(cmd_info, x+23,  y-1, 137, 44, 0, 0xFFFFFFFF)-- �������
			renderFontDrawText(text_rinfo, "��������", x+65, y+12, 0xebedf1FF)
		elseif id == 8 then
			renderDrawTexture(back, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)
			renderDrawTexture(cmd_info, x+23, y-1, 137, 44, 0, 0xFFFFFFFF)-- �������
			renderFontDrawText(text_rinfo, "����� ID", x+65, y+12, 0xebedf1FF)
		elseif id == 9 then
			renderDrawTexture(auncuff, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)		
			renderDrawTexture(cmd_info, x+21, y-1, 152, 44, 0, 0xFFFFFFFF)-- �������
			renderFontDrawText(text_rinfo, "����� ���������", x+60, y+12, 0xebedf1FF)
		elseif id == 10 then 
			renderDrawTexture(unfreeze, x, y-1, xpos, ypos, 0, 0xFFFFFFFF)
			renderDrawTexture(cmd_info, x+24,  y-1, 137, 44, 0, 0xFFFFFFFF) 
			renderFontDrawText(text_rinfo, "�����������", x+65, y+12, 0xebedf1FF)
		end 
		if isKeyJustPressed(0x01) then
			res = true -- ���� ����� � ������ ������� � ������ ���, ������� true ����������	
		end
	end
    return res -- ������������ ������ �������
end 

function imgui.NewInputText(lable, val, val1, width, hint, hintpos)
    local hint = hint and hint or ''
    local hintpos = tonumber(hintpos) and tonumber(hintpos) or 1
    local cPos = imgui.GetCursorPos()
    imgui.PushItemWidth(width)
    local result = imgui.InputText(lable, val, val1)
    if #ffi.string(val) == 0 then
        local hintSize = imgui.CalcTextSize(hint)
        if hintpos == 2 then imgui.SameLine(cPos.x + (width - hintSize.x) / 2)
        elseif hintpos == 3 then imgui.SameLine(cPos.x + (width - hintSize.x - 5))
        else imgui.SameLine(cPos.x + 5) end
        imgui.TextColored(imgui.ImVec4(1, 1, 1, 0.60), tostring(hint))
    end
    imgui.PopItemWidth()
    return result
end


function imgui.NewInputTextFlags(lable, val, val1, width, hint, hintpos)
    local hint = hint and hint or ''
    local hintpos = tonumber(hintpos) and tonumber(hintpos) or 1
    local cPos = imgui.GetCursorPos()
    imgui.PushItemWidth(width)
    local result = imgui.InputText(lable, val, val1, imgui.InputTextFlags.EnterReturnsTrue)
    if #ffi.string(val) == 0 then
        local hintSize = imgui.CalcTextSize(hint)
        if hintpos == 2 then imgui.SameLine(cPos.x + (width - hintSize.x) / 2)
        elseif hintpos == 3 then imgui.SameLine(cPos.x + (width - hintSize.x - 5))
        else imgui.SameLine(cPos.x + 5) end
        imgui.TextColored(imgui.ImVec4(1, 1, 1, 0.60), tostring(hint))
    end
    imgui.PopItemWidth()
    return result
end

function imgui.NewButton(text, x, y, sizeX, sizeY)
	imgui.SetCursorPos(imgui.ImVec2(x, y))
	local result = imgui.Button(u8(text), imgui.ImVec2(sizeX, sizeY))
	return result
end

function imgui.NewText(text, x, y)
	imgui.SetCursorPos(imgui.ImVec2(x,y))
	local result = imgui.Text(u8(text))
	return result
end 

function imgui.Link(link, text)
    text = text or link
    local tSize = imgui.CalcTextSize(text)
    local p = imgui.GetCursorScreenPos()
    local DL = imgui.GetWindowDrawList()
    local col = { 0xFFFF7700, 0xFFFF9900 } -- 1: ���� �������, 2 ���� ��� �������.
    if imgui.InvisibleButton("##" .. link, tSize) then os.execute("explorer " .. link) end
    local color = imgui.IsItemHovered() and col[1] or col[2]
    DL:AddText(p, color, text)
end

function imgui.TextColoredRGB(text)
    local style = imgui.GetStyle()
    local colors = style.Colors
    local ImVec4 = imgui.ImVec4
    local explode_argb = function(argb)
        local a = bit.band(bit.rshift(argb, 24), 0xFF)
        local r = bit.band(bit.rshift(argb, 16), 0xFF)
        local g = bit.band(bit.rshift(argb, 8), 0xFF)
        local b = bit.band(argb, 0xFF)
        return a, r, g, b
    end
    local getcolor = function(color)
        if color:sub(1, 6):upper() == 'SSSSSS' then
            local r, g, b = colors[1].x, colors[1].y, colors[1].z
            local a = tonumber(color:sub(7, 8), 16) or colors[1].w * 255
            return ImVec4(r, g, b, a / 255)
        end
        local color = type(color) == 'string' and tonumber(color, 16) or color
        if type(color) ~= 'number' then return end
        local r, g, b, a = explode_argb(color)
        return imgui.ImVec4(r/255, g/255, b/255, a/255)
    end
    local render_text = function(text_)
        for w in text_:gmatch('[^\r\n]+') do
            local text, colors_, m = {}, {}, 1
            w = w:gsub('{(......)}', '{%1FF}')
            while w:find('{........}') do
                local n, k = w:find('{........}')
                local color = getcolor(w:sub(n + 1, k - 1))
                if color then
                    text[#text], text[#text + 1] = w:sub(m, n - 1), w:sub(k + 1, #w)
                    colors_[#colors_ + 1] = color
                    m = n
                end
                w = w:sub(1, n - 1) .. w:sub(k + 1, #w)
            end
            if text[0] then
                for i = 0, #text do
                    imgui.TextColored(colors_[i] or colors[1], u8(text[i]))
                    imgui.SameLine(nil, 0)
                end
                imgui.NewLine()
            else imgui.Text(u8(w)) end
        end
    end
    render_text(text)
end

function imgui.reduchild(str_id, size, color, offset, ready)
    color = color or imgui.GetStyle().Colors[imgui.Col.Border]
	offset = offset or imgui.GetStyle().Colors[imgui.Col.Border]
	ready = ready
	local DL = imgui.GetWindowDrawList()
    local posS = imgui.GetCursorScreenPos()
    local rounding = imgui.GetStyle().ChildRounding
    local title = str_id:gsub('##.+$', '')
	local vec_color = imgui.ImVec4(1, 1, 1, 0.1)
    local sizeT = imgui.CalcTextSize(title)
    local padd = imgui.GetStyle().WindowPadding
    local bgColor = imgui.ColorConvertFloat4ToU32(imgui.GetStyle().Colors[imgui.Col.WindowBg])
    imgui.PushStyleColor(imgui.Col.ChildBg, imgui.ImVec4(0, 0, 0, 0))
    imgui.PushStyleColor(imgui.Col.Border, imgui.ImVec4(0, 0, 0, 0))
    imgui.BeginChild(str_id, size, true)
    imgui.Spacing()
    imgui.PopStyleColor(2)
    size.x = size.x == -1.0 and imgui.GetWindowWidth() or size.x
    size.y = size.y == -1.0 and imgui.GetWindowHeight() or size.y
	if ready then DL:AddRectFilled(posS, imgui.ImVec2(posS.x + size.x, posS.y + size.y), imgui.GetColorU32Vec4(offset), 9, -1, 2) end  --if ready == 1 then  end 
	DL:AddRect(posS, imgui.ImVec2(posS.x + size.x, posS.y + size.y), imgui.ColorConvertFloat4ToU32(color), 9, -1, 2)
end

function imgui.BeginTitleChild(str_id, size, color, offset)
    color = color or imgui.GetStyle().Colors[imgui.Col.Border]
    offset = offset or 30
    local DL = imgui.GetWindowDrawList()
    local posS = imgui.GetCursorScreenPos()
    local rounding = imgui.GetStyle().ChildRounding
    local title = str_id:gsub('##.+$', '')
	local vec_color = imgui.ImVec4(1, 1, 1, 0.1)
    local sizeT = imgui.CalcTextSize(title)
    local padd = imgui.GetStyle().WindowPadding
    local bgColor = imgui.ColorConvertFloat4ToU32(imgui.GetStyle().Colors[imgui.Col.WindowBg])
    imgui.PushStyleColor(imgui.Col.ChildBg, imgui.ImVec4(0, 0, 0, 0))
    imgui.PushStyleColor(imgui.Col.Border, imgui.ImVec4(0, 0, 0, 0))
    imgui.BeginChild(str_id, size, true)
    imgui.Spacing()
    imgui.PopStyleColor(2)
    size.x = size.x == -1.0 and imgui.GetWindowWidth() or size.x
    size.y = size.y == -1.0 and imgui.GetWindowHeight() or size.y
	DL:AddRect(posS, imgui.ImVec2(posS.x + size.x, posS.y + size.y), imgui.ColorConvertFloat4ToU32(color), 9, -1, 2)
	DL:AddLine(imgui.ImVec2(posS.x + offset + 65, posS.y), imgui.ImVec2((posS.x + 35) + sizeT.x + 75, posS.y), bgColor, 2)
    DL:AddText(imgui.ImVec2(posS.x + offset + 70, posS.y - (sizeT.y / 2)), -1, title)
end

function imgui.CenterTextSetting(text)
    imgui.SetCursorPos(imgui.ImVec2(imgui.GetWindowWidth()/2-imgui.CalcTextSize(u8(text)).x/2, 10))
    imgui.Text(u8(text))
end

function imgui.Cenerytext(text, Y)
    imgui.SetCursorPos(imgui.ImVec2(imgui.GetWindowWidth()/2-imgui.CalcTextSize(u8(text)).x/2, Y))
    imgui.Text(u8(text))
end

function imgui.Tooltip(text)
    if imgui.IsItemHovered() then
        imgui.BeginTooltip()
        imgui.Text(text)
        imgui.EndTooltip()
    end
end

function imgui.CenterColumnText(text)
	imgui.SetCursorPosX((imgui.GetColumnOffset() + (imgui.GetColumnWidth() / 2)) - imgui.CalcTextSize(text).x / 2)
	imgui.Text(text)
end

function imgui.VerticalSeparator()
	local pos = imgui.GetCursorScreenPos()
	local drawlist = imgui.GetWindowDrawList()
	local color = imgui.GetColorU32Vec4(imgui.GetStyle().Colors[imgui.Col.Separator])
	drawlist:AddLine(imgui.ImVec2(pos.x, pos.y - 12), imgui.ImVec2(pos.x, 0xFFFFFF), color)
end