return
{
    -- R1
    [0x31DF13] =
    {
        stChatInfo = 0x21A0E4,
        stInputInfo = 0x21A0E8,
        stLocalPlayer = 0x4A50,

        fnAddChatMessage = 0x645A0,
        fnSendMessage = 0x57F0,
        fnSendCommand = 0x65C60
    },
    -- R2
    [0x3195DD] =
    {
        stChatInfo = 0x21A0EC,
        stInputInfo = 0x21A0F0,
        stLocalPlayer = 0x4A70,

        fnAddChatMessage = 0x64670,
        fnSendMessage = 0x57E0,
        fnSendCommand = 0x65D30
    },
    -- R3
    [0x0CC4D0] =
    {
        stChatInfo = 0x26E8C8,
        stInputInfo = 0x26E8CC,
        stLocalPlayer = 0x4A80,

        fnAddChatMessage = 0x679F0,
        fnSendMessage = 0x5820,
        fnSendCommand = 0x69190
    },
    -- R4
    [0x0CBCB0] =
    {
        stChatInfo = 0x26E9F8,
        stInputInfo = 0x26E9FC,
        stLocalPlayer = 0x4C30,

        fnAddChatMessage = 0x68130,
        fnSendMessage = 0x5A00,
        fnSendCommand = 0x698C0
    },
    -- DL
    [0x0FDB60] =
    {
        stChatInfo = 0x2ACA10,
        stInputInfo = 0x2ACA14,
        stLocalPlayer = 0x4DB0,

        fnAddChatMessage = 0x67BE0,
        fnSendMessage = 0x5860,
        fnSendCommand = 0x69340
    }
}