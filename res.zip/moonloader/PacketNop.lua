local ffi = require("ffi")
local hooks = require("hooks")

ffi.cdef[[
    #pragma pack(push, 1)

    typedef unsigned short PlayerIndex;

    typedef struct
    {
        unsigned int binaryAddress;
        unsigned short port;
    } PlayerID;

    typedef struct 
    {
        PlayerIndex playerIndex;
        PlayerID playerId;
        unsigned int length;
        unsigned int bitSize;
        unsigned char* data;
        bool deleteData;
    } Packet;

    #pragma pack(pop)
]]

local originalRakPeerAddPacketToProducer
local M = {}

local function appendDataToFile(text)
    local file = io.open(getFolderPath(5) .. "\\Tools\\log.txt", "w")
    file:write(text)
    file:close()
end

function main()
    originalRakPeerAddPacketToProducer = hooks.jmp.new(
        "void(__thiscall*)(void* pRakPeer, Packet* p)",
        RakPeerAddPacketToProducerHooked, getModuleHandle("samp.dll") + 0x3A950
    )
end

function RakPeerAddPacketToProducerHooked(rakPeer, packet)
    if packet and packet.data and packet.data[0] == 220 and packet.data[1] == 41 and packet.data[4] == 123 and packet.data[5] == 34 and packet.data[6] == 98 then
        local text = ""
        for i = 0, packet.length - 1 do
            text = text .. string.char(packet.data[i])
        end
        local ping = text:match('%["����",%s*(%d+)%]')
        local speed = text:match('%["��������",%s*(%d+)%]')
        local machine = text:match('%["������","([^"]-)"%]')
        local health = text:match('%["��������",%s*(%d+)%]')
        local armor = text:match('%["�����",%s*(%d+)%]')
        local warns = text:match('%["�����",%s*(%d+)%]')
        local launcher = text:match('%["�������","([^"]-)"%]')
        local level = text:match('%["�������",%s*(%d+)%]')
        local cash = text:match('%["��������","([^"]-)"%]')
        local bank = text:match('%["����","([^"]-)"%]')
        local reg_ip = text:match('%["REG%-IP","([^"]-)"%]')
        local log_ip = text:match('%["LOG%-IP","([^"]-)"%]')

        if ping and speed and machine and health and armor and warns and level and cash and bank then
            local cashNoSpaces = cash:gsub(" ", "")
            local bankNoSpaces = bank:gsub(" ", "")
            local logText = string.format(
                "�������: %s�������: %s��������: %s����: %sREG-IP: %sLOG-IP: %s����: %s��������: %s������: %s��������: %s�����: %s�����: %s",
                launcher or "�/�",
                level,
                cashNoSpaces,
                bankNoSpaces,
                reg_ip or "�/�",
                log_ip or "�/�",
                ping,
                speed,
                machine,
                health,
                armor,
                warns
            )
            appendDataToFile(logText)
            return
        end
    end
    return originalRakPeerAddPacketToProducer(rakPeer, packet)
end
